
'use strict';

var app = angular.module('app', [
    'ngAnimate', // animations
//    'ngResource', // Rest
   'ngSanitize', // sanitizes html bindings (ex: sidebar.js)
    'ui.router', // UI Router
//    'ngStorage', // Local Storage
//    'angularSpinner',
 'ngCsv'

    //'ui.bootstrap', // ui-bootstrap (ex: carousel, pagination, dialog)
////        'angularSelectbox',
//    'ui.grid',

])
 

