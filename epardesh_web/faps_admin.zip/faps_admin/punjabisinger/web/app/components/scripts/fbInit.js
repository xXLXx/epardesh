
'use strict';

//var app = angular.module('fbInit', [])
//        .run(function($FB){
//  $FB.init('232178350466666');
//});
//    angular.module('app').config(function($mdThemingProvider) {
//  $mdThemingProvider.theme('docs-dark')
//    .primaryPalette('purple');

